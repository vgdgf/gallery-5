package com.telebackup.app.util

object Constants {
    const val NOTIFICATION_CHANNEL_ID = "backup_service_channel"
    const val NOTIFICATION_ID = 1001

    const val UPLOAD_WORK_NAME = "telegram_upload_work"

    // Telegram limits: bot uploads are capped at 50 MB per file via the Bot API.
    const val MAX_TELEGRAM_FILE_BYTES = 50L * 1024 * 1024

    // Image compression
    const val DEFAULT_JPEG_QUALITY = 85
    const val MAX_IMAGE_DIMENSION = 2560 // longest edge after downscale

    // Retry policy
    const val MAX_UPLOAD_RETRIES = 5
}
