package com.telebackup.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Compresses images before upload to save bandwidth and battery.
 * Videos are NOT re-encoded here (that is heavy and lossy); instead the
 * upload layer streams them as-is and rejects files over the Telegram limit.
 */
class MediaCompressor(private val context: Context) {

    /**
     * Returns a compressed JPEG copy in the app cache, or null if compression
     * was not beneficial / not possible (caller should then upload original).
     */
    fun compressImage(
        source: Uri,
        quality: Int = Constants.DEFAULT_JPEG_QUALITY,
        maxDimension: Int = Constants.MAX_IMAGE_DIMENSION,
    ): File? {
        return runCatching {
            // 1. Read bounds only to compute a sample size.
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(source)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val longest = max(bounds.outWidth, bounds.outHeight)
            val sample = computeSampleSize(longest, maxDimension)

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = context.contentResolver.openInputStream(source)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null

            // 2. Further scale if still larger than the target.
            val scaled = downscaleIfNeeded(bitmap, maxDimension)

            // 3. Write JPEG to cache.
            val out = File(context.cacheDir, "cmp_${System.nanoTime()}.jpg")
            FileOutputStream(out).use { fos ->
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, fos)
            }
            if (scaled != bitmap) scaled.recycle()
            bitmap.recycle()
            out
        }.getOrNull()
    }

    private fun computeSampleSize(longestEdge: Int, target: Int): Int {
        var sample = 1
        var edge = longestEdge
        while (edge / 2 >= target) {
            edge /= 2
            sample *= 2
        }
        return sample
    }

    private fun downscaleIfNeeded(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val longest = max(bitmap.width, bitmap.height)
        if (longest <= maxDimension) return bitmap
        val ratio = maxDimension.toFloat() / longest
        val w = (bitmap.width * ratio).roundToInt()
        val h = (bitmap.height * ratio).roundToInt()
        return Bitmap.createScaledBitmap(bitmap, w, h, true)
    }
}
