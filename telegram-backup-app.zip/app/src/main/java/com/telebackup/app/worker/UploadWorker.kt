package com.telebackup.app.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.telebackup.app.data.repository.BackupRepository
import com.telebackup.app.data.repository.QueueOutcome
import com.telebackup.app.util.Constants
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * Heavy lifting (network upload) runs here, off the main thread and subject to
 * WorkManager's battery/network constraints. It drains the queue one file at a
 * time and reschedules itself with exponential backoff if work remains.
 */
@HiltWorker
class UploadWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val repository: BackupRepository,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        repository.recoverStuck()

        var processed = 0
        while (processed < BATCH_LIMIT) {
            when (repository.uploadNext()) {
                QueueOutcome.UPLOADED -> processed++
                QueueOutcome.EMPTY -> return Result.success()
                QueueOutcome.NOT_CONFIGURED -> return Result.success()
                QueueOutcome.RETRY_LATER -> return Result.retry()
            }
        }
        // Still items left in this batch window -> let WorkManager re-run soon.
        return Result.retry()
    }

    companion object {
        private const val BATCH_LIMIT = 25

        fun enqueue(context: Context, wifiOnly: Boolean) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(
                    if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
                )
                .build()

            val request = OneTimeWorkRequestBuilder<UploadWorker>()
                .setConstraints(constraints)
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    30, TimeUnit.SECONDS,
                )
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                Constants.UPLOAD_WORK_NAME,
                ExistingWorkPolicy.APPEND_OR_REPLACE,
                request,
            )
        }
    }
}
