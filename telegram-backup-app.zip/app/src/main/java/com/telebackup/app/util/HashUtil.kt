package com.telebackup.app.util

import java.io.InputStream
import java.security.MessageDigest

/**
 * Produces a stable content hash used for deduplication.
 *
 * To stay fast on large videos we hash file size + the first and last 1 MB
 * rather than the whole stream. This is collision-resistant enough for
 * "same media file" detection while avoiding reading gigabytes of data.
 */
object HashUtil {

    private const val CHUNK = 1024 * 1024 // 1 MB

    fun quickHash(input: () -> InputStream, fileSize: Long): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(longToBytes(fileSize))

        input().use { stream ->
            val head = ByteArray(CHUNK)
            val read = stream.read(head)
            if (read > 0) digest.update(head, 0, read)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun longToBytes(value: Long): ByteArray {
        val result = ByteArray(8)
        var v = value
        for (i in 7 downTo 0) {
            result[i] = (v and 0xFF).toByte()
            v = v shr 8
        }
        return result
    }
}
